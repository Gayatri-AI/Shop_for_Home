CREATE DATABASE shopforhome;
Create Table admin;
Create Table cart;
Create Table discount;
Create Table do_order;
Create Table products;
Create Table user;