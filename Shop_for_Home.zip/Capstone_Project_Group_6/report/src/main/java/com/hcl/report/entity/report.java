package com.hcl.report.entity;

public class report {

}
