package com.hcl.report.repo;

public interface reportRepo {

}
