package com.hcl.admin.Entity;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;


import javax.persistence.JoinColumn;

@Entity
public class Admin {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer adminId;
	@Column(unique=true)
	private String adminname;
	private String adminpassword;
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminname=" + adminname + ", adminpassword=" + adminpassword + "]";
	}
	public Admin(Integer adminId, String adminname, String adminpassword) {
		super();
		this.adminId = adminId;
		this.adminname = adminname;
		this.adminpassword = adminpassword;
	}
	public Admin() {
		super();
	}
	public void setUser(List<User> user) {
		
	}
	public void setDiscount(List<Discount> Discount) {
		
	}
	public void setReport(List<Report> report) {
		// TODO Auto-generated method stub
		
	}
	

}
