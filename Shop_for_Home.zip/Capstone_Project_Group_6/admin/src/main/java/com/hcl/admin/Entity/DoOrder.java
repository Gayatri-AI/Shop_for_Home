package com.hcl.admin.Entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;

import lombok.AllArgsConstructor;

import lombok.NoArgsConstructor;


@Entity
@NoArgsConstructor
@AllArgsConstructor
public class DoOrder {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer orderId;
	private Integer cartId;
	@CreationTimestamp
	private Date date;
	public DoOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DoOrder(Integer orderId, Integer cartId, Date date) {
		super();
		this.orderId = orderId;
		this.cartId = cartId;
		this.date = date;
	}
	@Override
	public String toString() {
		return "DoOrder [orderId=" + orderId + ", cartId=" + cartId + ", date=" + date + "]";
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Integer getCartId() {
		return cartId;
	}
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
}