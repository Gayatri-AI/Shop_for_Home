package com.hcl.admin.Repo;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.hcl.admin.Entity.User;




public interface UserRepo extends CrudRepository<User,Integer>{


	User findByUsername(String username);


}