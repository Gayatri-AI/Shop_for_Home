package com.hcl.admin.Service;

import java.util.List;

import com.hcl.admin.Entity.Products;
import com.hcl.admin.Entity.User;
import com.hcl.admin.Entity.Admin;
import com.hcl.admin.Entity.Discount;
import com.hcl.admin.exceptions.ProductsCannotBeDeletedException;
import com.hcl.admin.exceptions.ProductsNotFoundException;
import com.hcl.admin.exceptions.UserCannotBeDeletedException;
import com.hcl.admin.exceptions.UserNotFoundException;

public interface AdminService {

	
	public Admin addAdmin(Admin admin);
	
	public List<Products> getAllproducts();
	public Products getProducts(Integer pId) throws ProductsNotFoundException;
	public Products addProducts(Products products);
	public Products updateProducts(Integer pId,Products products);
	public void deleteProducts(Integer pId) throws ProductsCannotBeDeletedException;

	

	public List<User> getAllusers();
	public User getUser(Integer uId) throws UserNotFoundException;
	public User updateUser(Integer uId,User user);
	public void deleteUser(Integer uId) throws UserCannotBeDeletedException;
//	public int monthSale(Integer month);
	
	public Discount addDiscount(Discount discount);
	
	


}
