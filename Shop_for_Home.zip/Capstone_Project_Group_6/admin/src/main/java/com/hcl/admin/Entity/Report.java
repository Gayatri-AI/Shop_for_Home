package com.hcl.admin.Entity;

public class Report {

}
