package com.hcl.admin.exceptions;

public class ProductsCannotBeDeletedException extends Exception {

	public ProductsCannotBeDeletedException(String message) {
		super(message);
	
	}

}
