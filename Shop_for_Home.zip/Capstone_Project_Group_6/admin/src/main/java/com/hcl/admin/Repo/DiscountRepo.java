package com.hcl.admin.Repo;

import org.springframework.data.repository.CrudRepository;

import com.hcl.admin.Entity.Discount;

public interface DiscountRepo extends CrudRepository<Discount,Integer>{



}