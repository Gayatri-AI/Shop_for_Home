package com.hcl.admin.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;


@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Products {
	
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true)
	private Integer pId;
	private String pName;
	private String pCat;
	private Integer price;
	private Integer stocks;
	
	


	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(
			name="Cart", 
			joinColumns= @JoinColumn(name="pId"),
			inverseJoinColumns=@JoinColumn(name="cartId"))
	private List<Cart> cart;
	

	
	public Products(Integer pId, String pName, String pCat, Integer price) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pCat = pCat;
		this.price = price;
	}
	public Integer getStocks() {
		return stocks;
	}
	public void setStocks(Integer stocks) {
		this.stocks = stocks;
	}
//	public List<Cart> getCart() {
//		return cart;
//	}
//	public void setCart(List<Cart> cart) {
//		this.cart = cart;
//	}
	public Products(Integer stocks, List<Cart> cart) {
		super();
		this.stocks = stocks;
		this.cart = cart;
	}
	public Integer getpId() {
		return pId;
	}
	public void setpId(Integer pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public String getpCat() {
		return pCat;
	}
	public void setpCat(String pCat) {
		this.pCat = pCat;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Products [pId=" + pId + ", pName=" + pName + ", pCat=" + pCat + ", price=" + price + ", stocks="
				+ stocks + ", cart=" + cart + "]";
	}
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
