package com.hcl.admin.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.admin.Entity.Admin;
import com.hcl.admin.Entity.Discount;
import com.hcl.admin.Entity.Products;
import com.hcl.admin.Entity.User;
import com.hcl.admin.Service.AdminService;
import com.hcl.admin.exceptions.ProductsCannotBeDeletedException;
import com.hcl.admin.exceptions.ProductsNotFoundException; 
import com.hcl.admin.exceptions.UserCannotBeDeletedException;
import com.hcl.admin.exceptions.UserNotFoundException;

@RestController//= @Controller + @ResponseBody

@RequestMapping("/admin")

public class AdminController {
	
	@Autowired
	AdminService service;

	
	@PostMapping(value="/products",consumes=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<Products> addProducts(@RequestBody Products products) 
	{
		if(products.getPrice()<=0) {
			throw new ProductsNotFoundException();
		}
		Products products1 =service.addProducts(products);
		return new ResponseEntity<Products>(products1,HttpStatus.CREATED);
	}

	@GetMapping("/products")
	public ResponseEntity<List<Products>> getAllproducts()
	{
		List<Products> productsList= service.getAllproducts();
		return new ResponseEntity<>(productsList,HttpStatus.OK);
	}


	@GetMapping("/products/{productsId}")
	public ResponseEntity getProducts(@PathVariable String productsId) throws ProductsNotFoundException 
	{
		ResponseEntity responseEntity=null;

		Products products= service.getProducts(Integer.parseInt(productsId));
		if(products!=null) {
			responseEntity = new ResponseEntity<>(products,HttpStatus.OK);


		}
		else {
			responseEntity=  new ResponseEntity<>("products is unavailible",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	@PutMapping("/products/{productsId}")
	public Products updateProducts(@PathVariable String productsId,@RequestBody Products products)
	{
		return service.updateProducts(Integer.parseInt(productsId), products);
	}
	
	
	@DeleteMapping("products/{productsId}")
	public ResponseEntity<String> deleteProducts(@PathVariable String productsId) throws ProductsCannotBeDeletedException 
	{
		service.deleteProducts(Integer.parseInt(productsId));
		return new ResponseEntity<>("the products is deleted successfully",HttpStatus.OK);
	}
	
//	@GetMapping("/{month}")
//	public int monthSale(@PathVariable Integer month)
//	{
//		return service.monthSale(month);
//		
//	}
	
	@GetMapping("/allcustomers")
	public ResponseEntity<List<User>> getAllusers()
	{
		List<User> userList= service.getAllusers();
		return new ResponseEntity<>(userList,HttpStatus.OK);
	}
	
	
	@GetMapping("/customer/{uId}")
	public ResponseEntity getUser(@PathVariable String uId) throws UserNotFoundException 
	{
		ResponseEntity responseEntity=null;

		User user= service.getUser(Integer.parseInt(uId));
		
		if(user!=null) {
			responseEntity = new ResponseEntity<>(user,HttpStatus.OK);


		}
		else {
			responseEntity=  new ResponseEntity<>("User is unavailible",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@PutMapping("/customer/{uId}")
	public User updateUser(@PathVariable String uId,@RequestBody User user)
	{
		return service.updateUser(Integer.parseInt(uId), user);
	}
	
	
	@DeleteMapping("/customer/{uId}")
	public ResponseEntity<String> deleteUser(@PathVariable String uId) throws UserCannotBeDeletedException 
	{
		service.deleteUser(Integer.parseInt(uId));
		return new ResponseEntity<>("the products is deleted successfully",HttpStatus.OK);
	}
	
	
	@PostMapping(value="/discount",consumes=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<Discount> addDiscount(@RequestBody Discount discount) 
	{
		Discount discount1 =service.addDiscount(discount);
		return new ResponseEntity<Discount>(discount1,HttpStatus.CREATED);
	}

	
	@PostMapping(value="/register",consumes=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<Admin> register(@RequestBody Admin admin) 
	{
		Admin admin1 =service.addAdmin(admin);
		return new ResponseEntity<Admin>(admin1,HttpStatus.CREATED);
	}

	
	

	
	

}
