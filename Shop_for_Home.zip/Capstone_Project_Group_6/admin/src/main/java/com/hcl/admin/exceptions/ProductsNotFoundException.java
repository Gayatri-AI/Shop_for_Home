package com.hcl.admin.exceptions;

public class ProductsNotFoundException extends RuntimeException {

	public ProductsNotFoundException() {
		super("Product doesn't exists");
	}

}
