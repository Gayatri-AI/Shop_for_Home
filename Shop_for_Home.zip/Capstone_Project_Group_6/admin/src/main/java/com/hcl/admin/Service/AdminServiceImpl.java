package com.hcl.admin.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.admin.Entity.Products;
import com.hcl.admin.Entity.Report;
import com.hcl.admin.Entity.User;
import com.hcl.admin.Entity.Admin;
import com.hcl.admin.Entity.Discount;
import com.hcl.admin.Repo.AdminRepo;
import com.hcl.admin.Repo.DiscountRepo;
import com.hcl.admin.Repo.OrderRepo;
import com.hcl.admin.Repo.ProductsRepo;
import com.hcl.admin.Repo.UserRepo;
import com.hcl.admin.exceptions.ProductsCannotBeDeletedException;
import com.hcl.admin.exceptions.ProductsNotFoundException;
import com.hcl.admin.exceptions.UserCannotBeDeletedException;
import com.hcl.admin.exceptions.UserNotFoundException;




@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	ProductsRepo repo;
	
	@Autowired
	OrderRepo repo2;
	
	@Autowired
	UserRepo repo1;
	
	@Autowired
	AdminRepo repo3;
	
	@Autowired
	DiscountRepo repo4;

	
	@Override
	public List<Products> getAllproducts() {
		List<Products> productsList=(List<Products>)repo.findAll();
		return productsList;

	}

	@Override
	public Products getProducts(Integer pId) throws ProductsNotFoundException {
			Optional<Products> opProducts=  repo.findById(pId);
			Products products =opProducts.orElseThrow(()->new ProductsNotFoundException());
			return products;
		}



	@Override
	public Products addProducts(Products products) {
		return repo.save(products);
		}


	@Override
	public Products updateProducts(Integer pId, Products products) {
		Products c=null;

	Optional<Products> opProducts=  repo.findById(pId);

	if(opProducts.isPresent()) {
		c=	repo.save(products);
	}
	return c;
}


	@Override
	public void deleteProducts(Integer productsId) throws ProductsCannotBeDeletedException {

		Optional<Products> c=null;
		c=repo.findById(productsId);
		Products products=c.orElseThrow(()->new ProductsCannotBeDeletedException("products with id "+productsId+" was not found"));
		repo.delete(products);
	}

	@Override
	public List<User> getAllusers() {
		List<User> userList=(List<User>)repo1.findAll();
		return userList;
	}

	@Override
	public User updateUser(Integer uId, User user) {
		User c=null;

		Optional<User> opUser=  repo1.findById(uId);

		if(opUser.isPresent()) {
			c=	repo1.save(user);
		}
		return c;
	}
	

	@Override
	public void deleteUser(Integer uId) throws UserCannotBeDeletedException {
		Optional<User> u=null;
		u=repo1.findById(uId);
		User user=u.orElseThrow(()->new UserCannotBeDeletedException("products with id "+uId+" was not found"));
		repo1.delete(user);
	}

	@Override
	public Admin addAdmin(Admin admin) {
		return repo3.save(admin);
	}

	@Bean
	public RestTemplate restTemplate() {
	    return new RestTemplate();
	}
	
	
	
	public Admin getUserByuId(Integer adminId)
	{
		Admin admin =repo3.findById(adminId).get();
		List<User> user=restTemplate().getForObject("http://user-microservice/user/"+adminId,List.class);
		admin.setUser(user);
        return admin;
	}
	
	public Admin getDiscountByuId(Integer adminId)
	{
		Admin admin =repo3.findById(adminId).get();

		List<Discount> discount=restTemplate().getForObject("http://discount-microservice/discount/"+adminId,List.class);
		admin.setDiscount(discount);
        return admin;

	}
	public Admin getReportByuId(Integer adminId)
	{
		Admin admin =repo3.findById(adminId).get();

		List<Report> report=restTemplate().getForObject("http://report-microservice/report/"+adminId,List.class);
		admin.setReport(report);
        return admin;

	}

	@Override
	public User getUser(Integer uId) throws UserNotFoundException {
		
				Optional<User> opUser=  repo1.findById(uId);
				User user =opUser.orElseThrow(()->new UserNotFoundException());
				return user;
			}

	@Override
	public Discount addDiscount(Discount discount) {
		return repo4.save(discount);
	}
}

//	@Override
//	public int monthSale(Integer month) {
//		
//		Integer sum = repo2.monthSale(month);
//		return sum;
//	}
	
	
	




