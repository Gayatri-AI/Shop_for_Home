package com.hcl.admin.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.hcl.admin.Entity.Products;



public interface ProductsRepo extends CrudRepository<Products,Integer>{

	@Query
	("Select p from Products p where p.pName =?1")
	Optional<Products> findByPName(String pName);
	
	@Query("Select p from Products p where p.pCat =?1")
	Optional<Products> findByPCat(String pCat);
	

}
