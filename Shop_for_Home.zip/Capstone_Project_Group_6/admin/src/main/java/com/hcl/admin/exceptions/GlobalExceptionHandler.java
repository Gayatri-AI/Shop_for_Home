package com.hcl.admin.exceptions;

import java.lang.annotation.Annotation;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Example;
import io.swagger.annotations.ResponseHeader;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	

	    @ExceptionHandler(UserNotFoundException.class)
	    public ResponseEntity<Object> handleExceptions( UserNotFoundException exception, WebRequest webRequest) {
	        ExceptionResponse response = new ExceptionResponse();
	        response.setMessage(" User Not found");
	        ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
	        return entity;
	    }
	    
	    
	    @ExceptionHandler(ProductsNotFoundException.class)
	    public ResponseEntity<Object> handleExceptions( ProductsNotFoundException exception, WebRequest webRequest) {
	        ExceptionResponse response = new ExceptionResponse();
	        response.setMessage(" Product Not found");
	        ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
	        return entity;
	    }
	    
	    @ExceptionHandler(ProductsCannotBeDeletedException.class)
	    public ResponseEntity<Object> handleExceptions( ProductsCannotBeDeletedException exception, WebRequest webRequest) {
	        ExceptionResponse response = new ExceptionResponse();
	        response.setMessage(" Products Cannot Be Deleted");
	        ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
	        return entity;
	    }
	    
	    @ExceptionHandler(UserCannotBeDeletedException.class)
	    public ResponseEntity<Object> handleExceptions( UserCannotBeDeletedException exception, WebRequest webRequest) {
	        ExceptionResponse response = new ExceptionResponse();
	        response.setMessage(" Products Cannot Be Deleted");
	        ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
	        return entity;
	    }
	    
	    
	    
}
	

