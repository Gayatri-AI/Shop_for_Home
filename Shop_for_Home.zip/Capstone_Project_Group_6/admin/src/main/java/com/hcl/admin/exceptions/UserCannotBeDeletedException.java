package com.hcl.admin.exceptions;

public class UserCannotBeDeletedException extends Exception {

	public UserCannotBeDeletedException(String message) {
		super(message);
	}

	
}
