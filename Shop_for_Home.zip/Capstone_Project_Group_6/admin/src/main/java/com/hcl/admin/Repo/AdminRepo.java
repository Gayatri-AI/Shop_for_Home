package com.hcl.admin.Repo;



import org.springframework.data.repository.CrudRepository;

import com.hcl.admin.Entity.Admin;
import com.hcl.admin.Entity.User;


public interface AdminRepo extends CrudRepository<Admin,Integer>{



}