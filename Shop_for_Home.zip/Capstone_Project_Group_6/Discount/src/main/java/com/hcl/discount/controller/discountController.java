package com.hcl.discount.controller;

public class discountController {

}
