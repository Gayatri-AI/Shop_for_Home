package com.hcl.discount.service;

public class discountService {

}
