package com.hcl.discount.repo;

public interface discountRepo {

}
