package com.hcl.discount.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class discount {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String memberType;
	private String discount;
	private String coupon;
	public String getCoupon() {
		return coupon;
	}
	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}
	public discount(String coupon) {
		super();
		this.coupon = coupon;
	}
	public String getMemberType() {
		return memberType;
	}
	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	@Override
	public String toString() {
		return "discount [memberType=" + memberType + ", discount=" + discount + ", coupon=" + coupon + "]";
	}
	public discount(String memberType, String discount) {
		super();
		this.memberType = memberType;
		this.discount = discount;
	}
	public discount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}