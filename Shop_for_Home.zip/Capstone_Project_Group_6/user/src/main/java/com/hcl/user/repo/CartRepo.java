package com.hcl.user.repo;

import org.springframework.data.repository.CrudRepository;

import com.hcl.user.entity.Cart;


public interface CartRepo extends CrudRepository<Cart,Integer> {

}
