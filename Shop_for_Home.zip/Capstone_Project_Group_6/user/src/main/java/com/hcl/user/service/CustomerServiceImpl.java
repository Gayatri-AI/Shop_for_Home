package com.hcl.user.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.hcl.user.entity.Cart;
import com.hcl.user.entity.DoOrder;
import com.hcl.user.entity.Products;
import com.hcl.user.entity.User;
import com.hcl.user.exceptions.ProductsNotFoundException;
import com.hcl.user.repo.CartRepo;
import com.hcl.user.repo.OrderRepo;
import com.hcl.user.repo.ProductsRepo;
import com.hcl.user.repo.UserRepo;



@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	ProductsRepo repo;
	
	@Autowired
	OrderRepo repo1;
	
	@Autowired
	UserRepo repo2;
	
	@Autowired
	CartRepo repo3;

	@Override
	public List<Products> getAllproducts() {
		List<Products> productsList=(List<Products>)repo.findAll();
		return productsList;

	}
	
	
	
//	@Override
//	public List<DoOrder> findByuId(Integer userId) 
//	{
//		return repo1.findByoId(userId);
//	}


	@Override
	public Products getProductByPName(String pName) throws ProductsNotFoundException {
		Optional<Products> opProducts=  repo.findByPName(pName);
		Products product1 =opProducts.orElseThrow(()->new ProductsNotFoundException());
		return product1;
	}
	
	@Override
	public List<Products> sort() {
		return repo.sort();
	}

	

	@Override
	public List<Products> getProductByPCat(String pCat) throws ProductsNotFoundException {
		return repo.findByPCat(pCat);
	}




	@Override
	public DoOrder addOrder(DoOrder doOrder) {
		return repo1.save(doOrder);
	}
	




//	public int userBill(Integer userId) {
//		Integer sum = repo1.userBill(userId);
//		return sum;
//	}



	@Override
	public User addUser(User user) {
		return repo2.save(user);
	}



	@Override
	public Cart addToCart(Cart cart) {
		return repo3.save(cart);

	}



	




	
	

}
