package com.hcl.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.user.entity.Cart;
import com.hcl.user.entity.DoOrder;
import com.hcl.user.entity.Products;
import com.hcl.user.entity.User;
import com.hcl.user.exceptions.ProductsNotFoundException;
import com.hcl.user.service.CustomerService;




@RestController
@RequestMapping("/User")
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	
	
	
	@GetMapping("/products")
	public ResponseEntity<List<Products>> getAllproducts()
	{
		List<Products> productsList= service.getAllproducts();
		return new ResponseEntity<>(productsList,HttpStatus.OK);
	}

	
	@GetMapping("/products/{pName}")
	public Products getProductByPName(@PathVariable String pName) throws ProductsNotFoundException 
	{
		
		return service.getProductByPName(pName);
	}
	
	@GetMapping("/{pCat}")
	public ResponseEntity<List<Products>> getProductByPCat(@PathVariable String pCat) throws ProductsNotFoundException
	{
		List<Products> products= service.getProductByPCat(pCat);
		return new ResponseEntity<>(products,HttpStatus.OK);
	}
	
	@GetMapping("/sortlowtohigh")
	public ResponseEntity<List<Products>> sort() 
	{
		List<Products> products= service.sort();
		return new ResponseEntity<>(products,HttpStatus.OK);
	}

	
	

	@PostMapping(value="/order",consumes=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<DoOrder> addOrder(@RequestBody DoOrder doOrder) 
	{
		DoOrder doOrder1 =service.addOrder(doOrder);
		return new ResponseEntity<DoOrder>(doOrder1,HttpStatus.CREATED);
	}
	
	@PostMapping(value="/cart",consumes=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<Cart> addToCart(@RequestBody Cart cart) 
	{
		Cart cart1 =service.addToCart(cart);
		return new ResponseEntity<Cart>(cart1,HttpStatus.CREATED);
	}
	
	

	
	
//	@GetMapping("bill/{uId}")
//	public int userBill(@PathVariable Integer uId)
//	{
//		return service.userBill(uId);
//		
//	}
	
//	@GetMapping("/order/{uId}")
//	public ResponseEntity<List<DoOrder>> findbyoId(@PathVariable Integer uId)
//	{
//		List<DoOrder> Order= service.findByuId(uId);
//		return new ResponseEntity<>(Order,HttpStatus.OK);
//	}
	
	
	@PostMapping(value="/register",consumes=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<User> register(@RequestBody User user) 
	{
		User user1 =service.addUser(user);
		return new ResponseEntity<User>(user1,HttpStatus.CREATED);
	}


}
