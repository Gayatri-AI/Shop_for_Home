package com.hcl.user.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Cart {
	
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private Integer cartId;
		private Integer userId;
		private Integer pId;
		private Integer quantity;
		
	
		@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
		@JoinTable(
				name="DoOrder", 
				joinColumns=@JoinColumn(name="cartId"),
				inverseJoinColumns=@JoinColumn(name="orderId"))
		private List<DoOrder> order;


		public List<DoOrder> getOrder() {
			return order;
		}


		public void setOrder(List<DoOrder> order) {
			this.order = order;
		}


		public Integer getCartId() {
			return cartId;
		}


		public void setCartId(Integer cartId) {
			this.cartId = cartId;
		}


		public Integer getUserId() {
			return userId;
		}


		public void setUserId(Integer userId) {
			this.userId = userId;
		}


		public Integer getpId() {
			return pId;
		}


		public void setpId(Integer pId) {
			this.pId = pId;
		}


		public Integer getQuantity() {
			return quantity;
		}


		public void setQuantity(Integer quantity) {
			this.quantity = quantity;
		}


		@Override
		public String toString() {
			return "Cart [cartId=" + cartId + ", userId=" + userId + ", pId=" + pId + ", quantity=" + quantity
					+ ", order=" + order + "]";
		}


		public Cart(Integer cartId, Integer userId, Integer pId, Integer quantity, List<DoOrder> order) {
			super();
			this.cartId = cartId;
			this.userId = userId;
			this.pId = pId;
			this.quantity = quantity;
			this.order = order;
		}


		public Cart() {
			super();
			// TODO Auto-generated constructor stub
		}
		
}