package com.hcl.user.exceptions;

public class ProductsNotFoundException extends Exception {

	public ProductsNotFoundException() {
		super("Product doesn't exists");
		// TODO Auto-generated constructor stub
	}

}
