package com.hcl.user.repo;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.hcl.user.entity.DoOrder;



public interface OrderRepo  extends CrudRepository<DoOrder,Integer> {

	
//	@Query("select c from Cart c, DoOrder o where c.userId= ?1 and c.userId=o.userId ")
//	List<DoOrder> findByoId(Integer uId);
//	
////	@Query("select sum(o.quantity * p.price) from Products p , DoOrder o where o.month=?1 and o.pId=p.pId")
////	int monthSale(Integer month);
////
//	@Query("select sum(c.quantity * p.price) from Products p , Cart c where c.userId=?1 and c.pId=p.pId ")
//	int userBill(Integer uId);
}
