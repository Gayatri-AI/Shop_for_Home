package com.hcl.user.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.hcl.user.entity.Cart;
import com.hcl.user.entity.DoOrder;
import com.hcl.user.entity.Products;
import com.hcl.user.entity.User;
import com.hcl.user.exceptions.ProductsNotFoundException;





public interface CustomerService {
	
	public List<Products> getAllproducts();
	
	public Products getProductByPName(String pName) throws ProductsNotFoundException;

	public DoOrder addOrder(DoOrder Order);
	
//	public List<DoOrder> findByuId(Integer userId);

	
	
//	public int userBill(Integer userId);

	public User addUser(User user);


	public Cart addToCart(Cart cart);

	public List<Products> getProductByPCat(String pCat) throws ProductsNotFoundException;


	public List<Products> sort();

	

}
